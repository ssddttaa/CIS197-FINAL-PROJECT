$(function () {
  var StockModel = Backbone.Model.extend({});
  window.StockModel = StockModel;
});
